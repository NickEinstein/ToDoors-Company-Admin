import { createAction } from "@reduxjs/toolkit";

export const logoutAction = createAction("common/logout");
