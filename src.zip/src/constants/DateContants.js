export const DateFormatEnum = {
  FORMAT: "dd-MM-yyyy",
  SPACE_dd_MMM_yyyy: "dd MMMM yyyy",
  HYPHEN_dd_MM_yyyy: "dd-MM-yyyy",
  HYPHEN_MM_dd_yyyy: "MM-ddd-yyyy",
};

export const DateLocaleEnum = {
  LOCALE: "en",
};
