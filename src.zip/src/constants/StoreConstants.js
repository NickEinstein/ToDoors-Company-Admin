export const StoreQueryTagEnum = {};
