// import { useSelector } from "react-redux";

function useThemeMode() {
  return "light";
  // return useSelector((state) => state.global.themeMode);
}

export default useThemeMode;
