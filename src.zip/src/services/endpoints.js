/* eslint-disable */

const paths = {
  // login: "payrollapi/api/Auth",
  login: "login",
  dashboardStats: "payrollapi/dashboardstats",


  postPassword2: "services/api/resetpassword/resetpassword",
  notification: "services/api/notifications",
  employeeProfile: "global/api/employee/profile",
};

export default paths;
